# F108/F115 v2 conformance coverage ledger

Status: candidate R5 inventory; not a freeze or acceptance record.

This ledger maps the remediation specification to the public, language-neutral
candidate corpus. Case identifiers are stable within candidate R5. The Python
reference validator executes the declarations but is not contract authority.

## Exact candidate R5 populations

The public population contains 168/168 path-qualified named observations: 23/23
expected transcript/schema accepts, 81/81 expected transcript/schema refusals,
41/41 pixel/PNG observations, 8/8 registry observations and 15/15 manifest
observations. Every self-test observation is now declared in the public corpus;
the private validator supplies execution, not additional cases.

The public population is enumerated by the `case_id` values in
`fixtures/valid/*.json`, `fixtures/invalid/*.json`, the diagnostic code entries
in `fixtures/invalid/diagnostic-cases.json`, `vectors` and `png_profiles` in
`fixtures/pixels/foreground-alpha-v2.json`, `png-byte-cases-v2.json`, and the
registry and manifest control-set files. `tools/count_cases.py` enumerates this
population without importing the validator. A count is not a completeness
claim: the gaps column below remains binding.

## Remediation mapping

| Finding | Candidate R5 controls | State and remaining gap |
| --- | --- | --- |
| H01 five-stage authority and semantic joins | 5/5 public valid transcripts; 22/22 `message-semantic-cases`; 7/7 `semantic-mutations`; 2/2 `image-background-mutations`; 8/8 public registry controls covering format-disabled, unknown/unresolved, unique-v2, remote, wrong-version, cyclic and duplicate-key behavior | **Reference-side partial.** The reference validator exercises every named cross-field rule family and refuses disabled format assertion. F108 and F115 have not returned identical outcomes or independent grading. |
| H02 linearizable cancellation | 3/3 named valid cancellation transcripts; 15/15 `lifecycle-cases-r2`; 3/3 `lifecycle-mutations` | **Reference transcript coverage only.** Intent/outcome joins, exact replay, second ID, changed replay, missing/out-of-order outcome, reused sequence, terminal exclusivity and client-time independence are covered. Causally forced before/during inference and both sides of the real reservation boundary, durable crash recovery, lost-outcome behavior and product replay remain consumer work. |
| H03 strict JSON and JCS+LF | 20/20 `raw-decode-cases` plus 2/2 Unicode cases | **Reference-side list covered.** The cases cover three-depth duplicates, BOM, invalid UTF-8, a lone surrogate, literal/escaped Unicode, key order, whitespace/LF, comments, non-finite numbers, negative zero, exponent and decimal spelling, the allowed uint32 maximum and 2^53 refusal. Independent F108/F115 parser and canonical-writer results remain absent. |
| M01 pixels and PNG | 16/16 hand-authored planes with 16/16 effective edge-settings echoes, 11/11 declarative PNG profiles and 14/14 deterministic PNG byte cases; mask/output geometry mutations in the semantic sets | **Reference-side list covered.** Threshold sides/equality, alpha/none, clamp, radius zero/one/maximum, 2-D edge repeat, 2/2 rounding-sensitive feather cases, the 67,125,249/67,125,249 maximum-radius sample bound and 17,116,938,495/17,116,938,495 maximum accumulator, opaque/straight/premultiplied alpha, final alpha cap and non-finite samples are covered. Real PNG bytes cover digest, CRC-checked chunk parsing, one/multiple IDAT, decoded pixels, geometry, colour/depth/interlace, ancillary/palette/alpha chunks and ordering. Product evidence that F115 performs 0/1 forbidden reprocessing passes remains open. |
| M02 background geometry and path-free results | `image-background-result`; 8/8 dedicated background/provenance mutations; combined input limits; background-input destination collision; result source/background path and byte injection; transparent and colour valid results | **Reference-side list covered.** Equal geometry, distinct request width/height mismatches, result background width/height/digest projection joins, path-bearing inputs, path-free source/background provenance, orientation enforcement and recursive result path/byte restrictions are exercised. The 2/2 product returns remain absent. |
| M03 closed diagnostics | 11/11 allowed error tuples, 3/3 warning codes, 6/6 invalid errors and 2/2 invalid warnings in `diagnostic-cases.json` | **Reference schema coverage only.** Tuple mismatches, unknown code, provider prose and diagnostic-path injection are refused. F115 local-catalog rendering, fixed unknown-code UI behavior and a product-level proof that no provider text crosses the bridge remain blocked on its repository and owner. |
| M04 public/private package boundary | Exact public/evidence/source manifests, 15/15 public manifest mutations, 4/4 source/sdist/wheel/installed inventories and 2/2 clean package builds | **Track-G carrier list covered.** Current-tree exactness covers changed byte and byte count, extra/missing/renamed resources, symlink, special file, duplicate entry, traversal/absolute/dot/empty/backslash/control paths and accidental private-evidence packaging. All 4/4 forms carry the same 46/46 manifest resources and 4/4 exact manifest copies, private evidence is absent from 4/4 forms, installed lookup has 0/2 source/current-directory dependencies, and both 2/2 artifact types are byte-identical across 2/2 clean builds. Matching F108/F115 pins and consumer package-resolution results remain absent. |

## Freeze gate disposition

Gates 1 and 2 have direct candidate evidence for the present population. Gates
4 through 7 have reference-side evidence but retain the product gaps above.
Gates 8 and 9 now have direct Track G carrier evidence but remain open pending
2/2 consumer package-resolution returns. Gates 3 and 10 remain blocked on
external or consumer results and cannot be closed from this tree.

The remaining authorities are: Track H and its independent grader for the
accepted launcher/freeze-adapter campaign; `fable_kilix` for the F108 adapter,
results and pin; the accountable F115 owner for repository authorization,
adapter, results and pin; the 2/2 consumer packaging owners for installed
resolution and equal pins against the Track G carrier; and the release owner for the
publishable contract-text licence. Until those returns and the remaining
external and product returns are closed, candidate R5 is not frozen G5b.
