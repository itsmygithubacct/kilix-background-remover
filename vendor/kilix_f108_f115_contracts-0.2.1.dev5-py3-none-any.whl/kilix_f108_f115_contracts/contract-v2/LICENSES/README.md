# Candidate licence inventory

This contract candidate contains no model, weight, dataset, generated media, or
third-party source payload. `jsonschema`, `referencing`, and `rfc8785` are
validation-tool dependencies and are not copied into `contract-v2/`.

This inventory does not grant publication authority. The release owner must
select and record the contract-text licence before the package can be frozen as
publishable bytes.
