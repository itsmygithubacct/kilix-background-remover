"""Installed lookup for the immutable F108/F115 public contract tree."""

from __future__ import annotations

from importlib.resources import files
from importlib.resources.abc import Traversable


def contract_root() -> Traversable:
    """Return the installed ``contract-v2`` resource root."""

    return files(__package__).joinpath("contract-v2")


__all__ = ["contract_root"]
